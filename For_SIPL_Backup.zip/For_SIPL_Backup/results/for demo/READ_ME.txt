To record new data save the raw text file\files in a directory with the current date in a directory called "measurements" on the same level of the "matlab code" directory.

The output labels will be in a directory called algo labels with the matching date provided in the script.