If you want to run the code correctly you need to rearange the folders as follows:
1.matlab code folder needs to be on the same level as measurments folder.
2. in addition to code, matlab code folder needs to contain the folders: - for demo (in order to run the demo code)
	   - results after grid search 
	   - same length templates
	   - templates
	   - variables for labeling 